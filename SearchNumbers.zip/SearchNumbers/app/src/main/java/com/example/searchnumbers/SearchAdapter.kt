package com.example.searchnumbers
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.newcontacts.R
import com.example.newcontacts.databinding.ItemContactBinding

class SearchAdapter(private var contacts: List<Cont>) : RecyclerView.Adapter<SearchAdapter.ViewHolder>() {

    private var filteredContacts: List<Cont> = contacts

    fun setFilteredContacts(filteredContacts: List<Cont>) {
        this.filteredContacts = filteredContacts
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_contact, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val contact = filteredContacts[position]
        holder.bind(contact)
    }

    override fun getItemCount(): Int {
        return filteredContacts.size
    }
    fun setContacts(contacts: List<Cont>) {
        this.contacts = contacts
        notifyDataSetChanged()
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val txtName:TextView=itemView.findViewById(R.id.name)
        private val txtNumber:TextView=itemView.findViewById(R.id.phone_number)
        fun bind(contact: Cont) {
            txtName.text = contact.Name
            txtNumber.text = contact.phoneNumber
        }
    }
}
