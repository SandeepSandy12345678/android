package com.example.searchnumbers

data class Cont(val Name: String, val phoneNumber:String,var isSelected:Boolean=false)
