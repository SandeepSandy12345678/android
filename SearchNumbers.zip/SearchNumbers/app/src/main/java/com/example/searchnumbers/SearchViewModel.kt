package com.example.searchnumbers
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class SearchViewModel : ViewModel() {
    private val _searchResults = MutableLiveData<List<Cont>>()
    val searchResults: LiveData<List<Cont>> = _searchResults
    val filteredContacts = MutableLiveData<List<Cont>>()


    // Function to perform the search logic
    fun searchContacts(query: String) {
        // Replace this with your actual search implementation
        // For example, you can filter the contacts based on the query
        val filteredResults = getContacts().filter { contact ->
            contact.Name.contains(query, ignoreCase = true) || contact.phoneNumber.contains(query, ignoreCase = true)
        }
        _searchResults.value = filteredResults
    }
    fun onCancelClicked() {
        Log.d("cancel Button", "cancel Tapped")
        // Add your logic here to handle cancel button click
        // For example, you can clear the search query or perform any other action

    }

    // Function to handle complete button click
    fun onCompleteClicked() {
        Log.d("complete Button", "complete Tapped")
        // Add your logic here to handle complete button click
        // For example, you can perform any action related to completing the search

    }

    // Function to fetch the initial list of contacts
     fun getContacts(): List<Cont> {
        // Replace this with your actual logic to fetch contacts
        // or use your own data source

        val contacts = mutableListOf<Cont>()
        contacts.add(Cont("Rey Mysterio", "6563 621 619"))
        contacts.add(Cont("Steve Austin", "8745 125 463"))
        contacts.add(Cont("Gold Berg", "9897 942 323"))
        contacts.add(Cont("John Cena", "7531 968 420"))
        contacts.add(Cont("Brock Lesner", "8426 931 705"))
        contacts.add(Cont("Jeff Hardy", "6248 913 750"))
        contacts.add(Cont("Shawn Michael", "9797 864 645"))
        contacts.add(Cont("The Rock", "8282 567 489"))
        contacts.add(Cont("The Rock 2","6368 652 147"))

        return contacts
    }
}