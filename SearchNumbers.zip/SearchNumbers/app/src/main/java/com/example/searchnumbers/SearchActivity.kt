package com.example.searchnumbers

import android.os.Bundle
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.newcontacts.R
import com.example.newcontacts.databinding.ActivityMainBinding


class SearchActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var searchAdapter: SearchAdapter
    private lateinit var searchViewModel: SearchViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (getSupportActionBar() != null) {
            getSupportActionBar()?.hide()

        }

        /*supportActionBar?.displayOptions = ActionBar.DISPLAY_SHOW_CUSTOM
        supportActionBar?.setCustomView(R.layout.action_bar)*/


        searchViewModel = ViewModelProvider(this)[SearchViewModel::class.java]

        searchViewModel.searchResults.observe(this, Observer { contacts ->
            searchAdapter.setFilteredContacts(contacts)
        })


        // Set up the RecyclerView
        binding.recyclerView.layoutManager = LinearLayoutManager(this)

        // Set up the adapter
        searchAdapter = SearchAdapter(searchViewModel.getContacts())
        binding.recyclerView.adapter = searchAdapter

        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener,android.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                // Perform search when the user submits the query
                searchViewModel.searchContacts(query)
                return true
            }

            override fun onQueryTextChange(newText: String): Boolean {
                // Perform search as the user types
                searchViewModel.searchContacts(newText)
                return true
            }
        })

    }

}
