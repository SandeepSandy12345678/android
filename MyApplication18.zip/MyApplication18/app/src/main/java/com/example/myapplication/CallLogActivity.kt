package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CallLogActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: CallAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_call_log)

        recyclerView = findViewById(R.id.recyclerView)

        val items = listOf(
            CallItem.CallDateHeader("2023/03/16"),
            CallItem.CallLog("3049", "AM 10:42", "3049", CallType.INCOMING),
            CallItem.CallDateHeader("2023/02/13"),
            CallItem.CallLog("3049", "PM 12:47", "3049", CallType.OUTGOING)
        ) + CallItem.CallLog("3049", "PM 01:23", "3049", CallType.OUTGOING) +
                CallItem.CallLog("3050","PM 9:00","3050",CallType.INCOMING) +
                CallItem.CallLog("3052","PM 6:00","3052",CallType.OUTGOING) +
                CallItem.CallDateHeader("2023/02/12") +
                CallItem.CallLog("3054","AM 7:00","3054",CallType.UNKNOWN) +
                CallItem.CallLog("3055","AM 3:00","3055",CallType.INCOMING) +
                CallItem.CallLog("3057","PM 4:00","3057",CallType.VOICEMAIL)


        adapter = CallAdapter(items)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        val btnHome = findViewById<Button>(R.id.btnHome)
        btnHome.setOnClickListener {
            Toast.makeText(this, "Clicked Home", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        val btnKeypad = findViewById<Button>(R.id.btnKeypad)
        btnKeypad.setOnClickListener {
            Toast.makeText(this, "Clicked Keypad", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, DialPad::class.java)
            startActivity(intent)
            // Launch the KeypadActivity
        }
    }
}
