package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnLogs: Button = findViewById(R.id.btnLogs)
        val btnGroups: Button = findViewById(R.id.btnGroups)
        val btnContacts: Button = findViewById(R.id.btnContacts)
        val btnFavorites: Button = findViewById(R.id.btnFavorites)
        val btnHome: Button = findViewById(R.id.btnHome)
        val btnKeypad: Button = findViewById(R.id.btnKeypad)
        val btnPtt: Button = findViewById(R.id.btn_ptt)

        // set click listeners for each button
        btnLogs.setOnClickListener {
            Toast.makeText(this, "clicked Logs", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, CallLogActivity::class.java)
            startActivity(intent)
        }

        btnGroups.setOnClickListener {
            /* handle click event for btnGroups */
            Toast.makeText(this, "clicked Groups", Toast.LENGTH_SHORT).show()
        }

        btnContacts.setOnClickListener {
            // handle click event for btnContacts
            Toast.makeText(this, "clicked Contacts", Toast.LENGTH_SHORT).show()
        }

        btnFavorites.setOnClickListener {
            // handle click event for btnFavorites
            Toast.makeText(this, "clicked Favorites", Toast.LENGTH_SHORT).show()
        }

        btnHome.setOnClickListener {
            // handle click event for btnHome
            Toast.makeText(this, "clicked Home", Toast.LENGTH_SHORT).show()
        }

        btnKeypad.setOnClickListener {
            // navigate to com.example.myapplication.DialPad activity
            Toast.makeText(this, "clicked KeyPad", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, DialPad::class.java)
            startActivity(intent)
        }

        btnPtt.setOnClickListener {
            // handle click event for btnPtt
            Toast.makeText(this, "clicked PTT", Toast.LENGTH_SHORT).show()
        }
    }
}
