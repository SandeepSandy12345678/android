@file:Suppress("unused")

package com.example.myapplication

enum class CallType {
    INCOMING,
    OUTGOING,
    MISSED,
    VOICEMAIL,
    REJECTED,
    BLOCKED,
    ANSWERED_EXTERNALLY,
    SENT,
    UNKNOWN
}
