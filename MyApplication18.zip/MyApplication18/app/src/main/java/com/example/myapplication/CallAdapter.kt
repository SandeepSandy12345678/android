package com.example.myapplication

import android.annotation.SuppressLint
import android.provider.CallLog
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.CallType.*

class CallAdapter(private val items: List<CallItem>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val VIEW_TYPE_DATE_HEADER = 0
        const val VIEW_TYPE_CALL_ITEM = 1
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            VIEW_TYPE_DATE_HEADER -> DateHeaderViewHolder(
                LayoutInflater.from(parent.context).inflate(
                    R.layout.list_item_call_date_header,
                    parent,
                    false
                )
            )
            VIEW_TYPE_CALL_ITEM -> CallItemViewHolder(
                LayoutInflater.from(parent.context).inflate(
                    R.layout.list_item_call_item,
                    parent,
                    false
                )
            )
            else -> throw IllegalArgumentException("Invalid view type")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = items[position]
        when (holder) {
            is DateHeaderViewHolder -> {
                holder.bind(item as CallItem.CallDateHeader)
            }
            is CallItemViewHolder -> {
                holder.bind(item as CallItem.CallLog)
            }
            else -> throw IllegalArgumentException("Invalid view holder type")


        }
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun getItemViewType(position: Int): Int {
        val item = items[position]
        return when (item) {
            is CallItem.CallDateHeader -> VIEW_TYPE_DATE_HEADER
            is CallItem.CallLog -> VIEW_TYPE_CALL_ITEM
        }
    }

    inner class DateHeaderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvDateHeader: TextView = itemView.findViewById(R.id.tvDateHeader)

        fun bind(dateHeader: CallItem.CallDateHeader) {
            tvDateHeader.text = dateHeader.date
        }
    }

    inner class CallItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvCallerName: TextView = itemView.findViewById(R.id.CallerName)
        private val tvCallNumber: TextView = itemView.findViewById(R.id.CallNumber)
        private val tvCallTime: TextView = itemView.findViewById(R.id.CallTime)
        private val ivCallType: ImageView = itemView.findViewById(R.id.CallType)

        fun bind(callItem: CallItem.CallLog) {
            tvCallerName.text = callItem.callerName
            tvCallTime.text = callItem.callTime
            tvCallNumber.text = callItem.callNumber

            val callTypeDrawableRes = when (callItem.callType) {
                INCOMING -> R.drawable.ic_callreceived
                OUTGOING -> R.drawable.ic_callsent
                MISSED -> R.drawable.ic_missedcall
                BLOCKED -> R.drawable.ic_callblocked
                REJECTED -> R.drawable.ic_callrejected
                VOICEMAIL -> R.drawable.ic_voicemail
                ANSWERED_EXTERNALLY -> TODO()
                UNKNOWN -> R.drawable.ic_unknowncall
                SENT -> R.drawable.ic_callsent
            }
            ivCallType.setImageResource(callTypeDrawableRes)
        }
    }
}
