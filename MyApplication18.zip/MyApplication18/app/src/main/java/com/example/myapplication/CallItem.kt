package com.example.myapplication

sealed class CallItem {


    data class CallLog(val callerName: String, val callTime: String, val callNumber: String, val callType: CallType) : CallItem()
    data class CallDateHeader(val date: String) : CallItem()
}

