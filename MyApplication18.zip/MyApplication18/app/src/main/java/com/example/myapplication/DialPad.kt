package com.example.myapplication

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class DialPad : AppCompatActivity() {

    private lateinit var mNumberEditText: EditText
    private lateinit var mBackspaceButton: ImageButton
    private lateinit var mDialButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dialpad)

        mNumberEditText = findViewById(R.id.type)
        mBackspaceButton = findViewById(R.id.imageButton)
        mDialButton = findViewById(R.id.btn_ptt)

        val textViewIds = arrayOf(
            R.id.txt_0, R.id.txt_1, R.id.txt_2, R.id.txt_3,
            R.id.txt_4, R.id.txt_5, R.id.txt_6, R.id.txt_7,
            R.id.txt_8, R.id.txt_9, R.id.txt_star, R.id.txt_hash
        )

        for (textViewId in textViewIds) {
            val textView = findViewById<TextView>(textViewId)
            textView.setOnClickListener {
                val buttonText = textView.text.toString()
                if (buttonText.length > 1) {
                    // Button has letters and a number
                    val letters = buttonText.toCharArray().toTypedArray()
                    mNumberEditText.append(letters[0].toString())
                    mNumberEditText.append(letters[1].toString())
                } else {
                    // Button only has a number
                    mNumberEditText.append(buttonText)
                }
            }
        }

        mBackspaceButton.setOnClickListener {
            val length: Int = mNumberEditText.length()
            if (length > 0) {
                mNumberEditText.text.delete(length - 1, length)
            }
        }

        mDialButton.setOnClickListener {
            val phoneNumber: String = mNumberEditText.text.toString()
            Toast.makeText(this, "clicked PTT", Toast.LENGTH_SHORT).show()
            if (!TextUtils.isEmpty(phoneNumber)) {
                // Make a phone call
//                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
//                startActivity(dialIntent)
            }
        }
    }
}
