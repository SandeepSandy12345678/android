package com.example.newcontacts.contacts

enum class ButtonClickEvent {
    DELETE,
    CREATE_GROUP,
    IMPORT_CONTACTS,
    EXPORT_CONTACTS,
    ADD_TO_FAVORITES,
    SORT_BY,
    CLOSE
}