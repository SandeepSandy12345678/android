package com.example.newcontacts.searchnumbers

import android.content.Context
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class SearchViewModel : ViewModel() {
    private val _cont = MutableLiveData<List<Cont>>()
    val cont: LiveData<List<Cont>> = _cont

    private val _searchResults = MutableLiveData<List<Cont>>()
    val searchResults: LiveData<List<Cont>> = _searchResults

    init {
        // Assuming you have a method to fetch the initial list of contacts
        fetchContacts()
    }

    // Function to fetch the initial list of contacts
    private fun fetchContacts() {
        // Replace this with your actual logic to fetch contacts
        // For example, you can fetch contacts from a database or API
        // and update _cont with the fetched contacts

        // Mock data for example
        val mockContacts = getMockContacts()
        _cont.value = mockContacts
    }

    fun search(query: String) {
        // Filter the contacts based on the query
        val filteredResults = cont.value?.filter { cont ->
            // Perform the search logic here
            // You can modify this condition based on your requirements
            cont.Name.contains(query, ignoreCase = true) || cont.phoneNumber.contains(query, ignoreCase = true)
        }
        val nonNullResults = filteredResults?.filterNotNull()

        _searchResults.value = nonNullResults!!
    }


    // Function to handle cancel button click
    fun onCancelClicked() {
        Log.d("cancel Button", "cancel Tapped")
        // Add your logic here to handle cancel button click
        // For example, you can clear the search query or perform any other action

    }

    // Function to handle complete button click
    fun onCompleteClicked() {
        Log.d("cancel Button", "cancel Tapped")
        // Add your logic here to handle complete button click
        // For example, you can perform any action related to completing the search

    }

    // Helper function to generate mock contacts
    private fun getMockContacts(): List<Cont> {
        // Replace this with your actual logic to fetch contacts
        // or use your own data source

        val contacts = mutableListOf<Cont>()
        contacts.add(Cont("John Doe", "1234567890"))
        contacts.add(Cont("Jane Smith", "9876543210"))
        contacts.add(Cont("David Johnson", "5555555555"))
        contacts.add(Cont("Emily Davis", "9999999999"))
        return contacts
    }

    private fun showToast(context: Context, message: String) {
        // Show a toast message
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
