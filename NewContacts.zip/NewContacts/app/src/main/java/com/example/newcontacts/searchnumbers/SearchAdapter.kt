package com.example.newcontacts.searchnumbers

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.newcontacts.databinding.NumbersBinding

class SearchAdapter : ListAdapter<Cont, SearchAdapter.SearchViewHolder>(SearchResultDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SearchViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = NumbersBinding.inflate(inflater, parent, false)
        return SearchViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SearchViewHolder, position: Int) {
        val searchResult = getItem(position)
        holder.bind(searchResult)
    }

    inner class SearchViewHolder(private val binding: NumbersBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(cont: Cont) {
            binding.executePendingBindings()
        }
    }
}

class SearchResultDiffCallback : DiffUtil.ItemCallback<Cont>() {
    override fun areItemsTheSame(oldItem: Cont, newItem: Cont): Boolean {
        return oldItem.phoneNumber == newItem.phoneNumber
    }

    override fun areContentsTheSame(oldItem: Cont, newItem:Cont): Boolean {
        return oldItem == newItem
    }

}
