 package com.example.newcontacts.contacts
//
//import android.content.Context
//import android.view.LayoutInflater
//import android.widget.Button
//import android.widget.Toast
//import androidx.appcompat.app.AlertDialog
//import androidx.lifecycle.MutableLiveData
//import androidx.lifecycle.ViewModel
//
//class CustomDialog(context: Context) {
//    private val alertDialogView = AlertDialogView()
//
//    // Create and show the custom dialog
//    fun showCustomDialog() {
//        val dialogBuilder = AlertDialog.Builder(context)
//            .setTitle("Custom Dialog")
//            .setPositiveButton("OK") { _, _ ->
//                alertDialogView.onDeleteClicked()
//            }
//            .setNegativeButton("Cancel") { _, _ ->
//                // Handle Cancel button click
//            }
//
//        val customDialogView = LayoutInflater.from(context).inflate(R.layout.custom_dialog_layout, null)
//        dialogBuilder.setView(customDialogView)
//
//        val dialog = dialogBuilder.create()
//        dialog.show()
//
//        // Access methods from AlertDialogView
//        customDialogView.findViewById<Button>(R.id.delete).setOnClickListener {
//            alertDialogView.onDeleteClicked()
//        }
//    }
//
//    // Access methods from AlertDialogView
//    fun onDeleteClicked() {
//        alertDialogView.onDeleteClicked()
//    }
//
//    // Access methods from AlertDialogView
//    fun onCreateGroupClicked() {
//        alertDialogView.onCreateGroupClicked()
//    }
//
//    // Access methods from AlertDialogView
//    fun onImportContactsClicked() {
//        alertDialogView.onImportContactsClicked()
//    }
//
//    // Access methods from AlertDialogView
//    fun onExportContactsClicked() {
//        alertDialogView.onExportContactsClicked()
//    }
//
//    // Access methods from AlertDialogView
//    fun onAddToFavoritesClicked() {
//        alertDialogView.onAddToFavoritesClicked()
//    }
//
//    // Access methods from AlertDialogView
//    fun onSortByClicked() {
//        alertDialogView.onSortByClicked()
//    }
//
//    // Access methods from AlertDialogView
//    fun onCloseClicked() {
//        alertDialogView.onCloseClicked()
//    }
//}
//
