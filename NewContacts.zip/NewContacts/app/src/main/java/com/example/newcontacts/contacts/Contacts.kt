package com.example.newcontacts

data class Contact(val name: String, val pttNumber: String){
    override fun toString(): String {
        return "$name - $pttNumber"
    }
}
