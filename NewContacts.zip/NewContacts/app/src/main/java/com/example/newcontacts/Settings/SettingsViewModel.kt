package com.example.newcontacts.Settings
import android.content.Context
import android.view.View
import android.widget.Toast
import androidx.lifecycle.ViewModel

class SettingsViewModel(private val context: Context) : ViewModel() {

    // Sound Settings onClick method
    fun onSoundSettingsClicked(view: View) {
        showToast("Sound Settings Clicked")
        // Add your logic here for handling the sound settings button click
    }

    // Quick PTT onClick method
    fun onQuickPttClicked(view: View) {
        showToast("Quick PTT Clicked")
        // Add your logic here for handling the quick PTT button click
    }

    // Etc onClick method
    fun onEtcClicked(view: View) {
        showToast("Etc Clicked")
        // Add your logic here for handling the etc button click
    }

    // Import Settings onClick method
    fun onImportSettingsClicked(view: View) {
        showToast("Import Settings Clicked")
        // Add your logic here for handling the import settings button click
    }

    // Export Settings onClick method
    fun onExportSettingsClicked(view: View) {
        showToast("Export Settings Clicked")
        // Add your logic here for handling the export settings button click
    }

    // Logout onClick method
    fun onLogoutClicked(view: View) {
        showToast("Logout Clicked")
        // Add your logic here for handling the logout button click
    }

    private fun showToast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

}
