package com.example.newcontacts.searchnumbers

data class Cont(val Name: String, val phoneNumber:String)
