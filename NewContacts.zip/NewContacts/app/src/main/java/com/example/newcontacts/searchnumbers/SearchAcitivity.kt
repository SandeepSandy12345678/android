package com.example.newcontacts.searchnumbers
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.widget.addTextChangedListener
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.example.newcontacts.R
import com.example.newcontacts.databinding.SelectContactsBinding
import com.example.newcontacts.searchnumbers.SearchAdapter
import com.example.newcontacts.searchnumbers.SearchViewModel

class SearchActivity : AppCompatActivity() {
    private lateinit var searchViewModel: SearchViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Set up data binding
        val binding: SelectContactsBinding = DataBindingUtil.setContentView(this, R.layout.select_contacts)

        // Instantiate the ViewModel
        searchViewModel = ViewModelProvider(this)[SearchViewModel::class.java]

        // Set the ViewModel in the binding
        binding.searchViewModel = searchViewModel

        // Set up the RecyclerView and adapter
        val recyclerView: RecyclerView = binding.recyclerView
        val searchAdapter = SearchAdapter()
        recyclerView.adapter = searchAdapter

        // Set up the search functionality
        val searchEditText: EditText = binding.search
        searchEditText.addTextChangedListener { editable ->
            val query = editable?.toString() ?: ""
            searchViewModel.search(query)
        }

        // Observe the search results in the ViewModel and update the adapter
        searchViewModel.searchResults.observe(this) { results ->
            searchAdapter.submitList(results)
        }

        // Set up click listeners for Cancel and Complete buttons
        binding.cancel.setOnClickListener {
            Toast.makeText(this, "Cancel clicked", Toast.LENGTH_SHORT).show()
        }

        binding.complete.setOnClickListener {
            Toast.makeText(this, "Complete clicked", Toast.LENGTH_SHORT).show()
        }
    }
}
