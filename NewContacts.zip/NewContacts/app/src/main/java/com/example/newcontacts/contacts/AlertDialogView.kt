package com.example.newcontacts.contacts

import android.content.Context
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class AlertDialogView : ViewModel() {
    // Create a MutableLiveData to hold the button click events
    val buttonClickEvent: MutableLiveData<ButtonClickEvent> = MutableLiveData()

    // Define the ButtonClickEvent enum class
    enum class ButtonClickEvent {
        DELETE,
        CREATE_GROUP,
        IMPORT_CONTACTS,
        EXPORT_CONTACTS,
        ADD_TO_FAVORITES,
        SORT_BY,
        CLOSE
    }

    // Method to handle delete button click
    fun onDeleteClicked() {
        buttonClickEvent.value = ButtonClickEvent.DELETE
    }

    // Method to handle create group button click
    fun onCreateGroupClicked() {
        buttonClickEvent.value = ButtonClickEvent.CREATE_GROUP
    }

    // Method to handle import contacts button click
    fun onImportContactsClicked() {
        buttonClickEvent.value = ButtonClickEvent.IMPORT_CONTACTS
    }

    // Method to handle export contacts button click
    fun onExportContactsClicked() {
        buttonClickEvent.value = ButtonClickEvent.EXPORT_CONTACTS
    }

    // Method to handle add to favorites button click
    fun onAddToFavoritesClicked() {
        buttonClickEvent.value = ButtonClickEvent.ADD_TO_FAVORITES
    }

    // Method to handle sort by button click
    fun onSortByClicked() {
        buttonClickEvent.value = ButtonClickEvent.SORT_BY
    }

    // Method to handle close button click
    fun onCloseClicked() {
        buttonClickEvent.value = ButtonClickEvent.CLOSE
    }

    // Helper method to show toast message
    fun showToast(message: String, context: Context) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
