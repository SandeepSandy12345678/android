package com.example.newcontacts.Settings

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.newcontacts.R
import com.example.newcontacts.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding
    private lateinit var viewModel: SettingsViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.settings_main)

        viewModel = SettingsViewModel(applicationContext)
        binding.settingViewModel = viewModel

// Set click listeners for the views
        binding.soundSettings.setOnClickListener { view ->
            viewModel.onSoundSettingsClicked(view)
            showToast("Sound Settings Clicked")
        }

        binding.quickPtt.setOnClickListener { view ->
            viewModel.onQuickPttClicked(view)
            showToast("Quick PTT Clicked")
        }

        binding.etc.setOnClickListener { view ->
            viewModel.onEtcClicked(view)
            showToast("Etc Clicked")
        }

        binding.importSettings.setOnClickListener { view ->
            viewModel.onImportSettingsClicked(view)
            showToast("Import Settings Clicked")
        }

        binding.exportSettings.setOnClickListener { view ->
            viewModel.onExportSettingsClicked(view)
            showToast("Export Settings Clicked")
        }

    }
        private fun showToast(message: String) {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

}
