package com.example.newcontacts.contacts

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.newcontacts.Contact

class MainViewModel(initialName: String, initialPttNumber: String) : ViewModel() {

    private val _name = MutableLiveData(initialName)
    val name: LiveData<String> = _name

    private val _pttNumber = MutableLiveData(initialPttNumber)
    val pttNumber: LiveData<String> = _pttNumber

    val _saved = MutableLiveData(false)
    val saved: LiveData<Boolean> = _saved

    private val _contacts = MutableLiveData<List<Contact>>(emptyList())
    val contacts: LiveData<List<Contact>> = _contacts

    private val _validation = MutableLiveData(true)
    val validation: LiveData<Boolean> = _validation

    // Method to update the name value
    fun updateName(newName: String) {
        _name.value = newName
    }

    // Method to update the pttNumber value
    fun updatePttNumber(newPttNumber: String) {
        _pttNumber.value = newPttNumber
    }


    // Method to save the contact
    fun saveContact() {
//        Log.d("MainActivityLogs", "saveContact: ")
        val name = _name.value.orEmpty()
        val pttNumber = _pttNumber.value

        if (name.isNullOrBlank()) {
            return
        }
        Log.d("MainActivityLogs", "Saving contact:$pttNumber")

        _saved.value = pttNumber.isNullOrBlank() || pttNumber.length < 10
//        val contact = Contact(name, pttNumber)

//        Log.d("TAG log", "saveContact: $contact")
    }

    // Method to reset the contact
    fun resetContact() {
        _name.value = ""
        _pttNumber.value = ""
        _saved.value = false
        _validation.value = true
    }

    // Method to handle discard button click
    fun onDiscardClicked() {
        resetContact()
    }

    // Method to handle save button click
    fun onSaveClicked() {
        saveContact()
    }
    fun isContactValid(): Boolean {
        return name.value?.isNotBlank() == true && pttNumber.value?.length == 10
    }
    fun getContact(): String {
        val name = _name.value ?: ""
        val pttNumber = _pttNumber.value ?: ""
        return "$name - $pttNumber"
    }

}
