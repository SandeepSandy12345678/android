package com.example.newcontacts.contacts

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class MainViewModelFactory(private val defaultName: String, private val defaultPttNumber: String) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(defaultName, defaultPttNumber) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }

}
