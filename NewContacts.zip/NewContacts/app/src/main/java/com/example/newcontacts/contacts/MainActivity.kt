package com.example.newcontacts.contacts

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.newcontacts.R
import com.example.newcontacts.databinding.ActivityMainBinding
import com.example.newcontacts.databinding.OptionsTableBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var optionsBinding: OptionsTableBinding
    private lateinit var alertDialogView: AlertDialogView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        val factory = MainViewModelFactory("", "")
        viewModel = ViewModelProvider(this, factory)[MainViewModel::class.java]
        binding.mainViewModel = viewModel
        binding.lifecycleOwner = this

        // Set up EditText change listeners
        binding.nameEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                viewModel.updateName(s?.toString() ?: "")
                if (s.isNullOrBlank()) {
                    Toast.makeText(binding.root.context, "Invalid name", Toast.LENGTH_SHORT).show()
                }
            }

            override fun afterTextChanged(s: Editable?) {}

        })

        binding.pttNumberEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s.isNullOrBlank()) {
                    Toast.makeText(
                        this@MainActivity,
                        "Invalid number: must not be empty",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    // Update the view model
                    viewModel.updatePttNumber(s.toString())
                }
            }

            override fun afterTextChanged(s: Editable?) {}
        })

        // Observe name and pttNumber changes
        viewModel.name.observe(this, Observer { newName ->
            // Handle name change here
            if (binding.nameEditText.text.toString() != newName) {
                binding.nameEditText.setText(newName)
            }
        })

        viewModel.pttNumber.observe(this, Observer { newPttNumber ->
            // Handle pttNumber change here
            if (binding.pttNumberEditText.text.toString() != newPttNumber) {
                binding.pttNumberEditText.setText(newPttNumber)
            }
        })

        viewModel._saved.observe(this) {
            val pttNumber: String = binding.pttNumberEditText.text.toString()
            if (pttNumber.isNullOrBlank() || pttNumber.length < 10) {
                Toast.makeText(this, "Please check the number ", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, " $pttNumber saved ", Toast.LENGTH_SHORT).show()
            }
        }

        viewModel.saved.observe(this) { saved ->
            Log.d("MainActivityLogs", " is invalid: $saved")
        }

        // Set up "Save" button OnClickListener
        binding.saveButton.setOnClickListener {
            // Get the new name and pttNumber from the EditTexts
            val newName = binding.nameEditText.text.toString()
            val newPttNumber = binding.pttNumberEditText.text.toString()

            // Update the name and pttNumber in the viewModel
            viewModel.updateName(newName)
            viewModel.updatePttNumber(newPttNumber)

            // Save the updated contact if both name and pttNumber are valid
            if (viewModel.isContactValid()) {
                viewModel.saveContact()
            }
        }

        // Set up "Discard" button OnClickListener
        binding.discardButton.setOnClickListener {
            viewModel.resetContact()
            binding.nameEditText.text.clear()
            binding.pttNumberEditText.setText("") // Clear the text here
            viewModel.updatePttNumber("") // Set the pttNumber value to an empty string
            Toast.makeText(this, "Discarded", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun getToastMessage(buttonClickEvent: ButtonClickEvent): String {
        return when (buttonClickEvent) {
            ButtonClickEvent.DELETE -> "Delete button clicked"
            ButtonClickEvent.CREATE_GROUP -> "Create group button clicked"
            ButtonClickEvent.IMPORT_CONTACTS -> "Import Contacts button clicked"
            ButtonClickEvent.EXPORT_CONTACTS -> "Export Contacts button clicked"
            ButtonClickEvent.ADD_TO_FAVORITES -> "Add to favorites button clicked"
            ButtonClickEvent.SORT_BY -> "Sort by button clicked"
            ButtonClickEvent.CLOSE -> "Close button clicked"
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_options -> {
                showOptionsDialog()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showOptionsDialog() {
        val dialogBinding = DataBindingUtil.inflate<OptionsTableBinding>(
            LayoutInflater.from(this),
            R.layout.options_table,
            null,
            false
        )

        val dialog = AlertDialog.Builder(this, R.style.alertDialogStyle)
            .setView(dialogBinding.root)
            .create()

        val alertDialogView = AlertDialogView()
        dialogBinding.alertDialogView = alertDialogView

        alertDialogView.buttonClickEvent.observe(this) { event ->
            when (event) {
                AlertDialogView.ButtonClickEvent.DELETE -> {
                    showToast("Delete button clicked")
                }
                AlertDialogView.ButtonClickEvent.CREATE_GROUP -> {
                    showToast("Create group button clicked")
                }
                AlertDialogView.ButtonClickEvent.IMPORT_CONTACTS -> {
                    showToast("Import Contacts button clicked")
                }
                AlertDialogView.ButtonClickEvent.EXPORT_CONTACTS -> {
                    showToast("Export Contacts button clicked")
                }
                AlertDialogView.ButtonClickEvent.ADD_TO_FAVORITES -> {
                    showToast("Add to favorites button clicked")
                }
                AlertDialogView.ButtonClickEvent.SORT_BY -> {
                    showToast("Sort by button clicked")
                }
                AlertDialogView.ButtonClickEvent.CLOSE -> {
                    showToast("Close button clicked")
                    dialog.dismiss()
                }
            }
        }

        dialog.show()
    }

}